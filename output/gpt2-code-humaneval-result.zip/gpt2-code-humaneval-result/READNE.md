﻿# GPT2 Code Generation - HumanEval Evaluation Result

## Model Information
- Model: GPT2-small (fine-tuned on 100% code dataset)
- Task: Python Code Generation
- Benchmark: HumanEval (164 test problems)

## Evaluation Setup
- GPU: A100
- Precision: bfloat16
- Samples per task: 10
- Metrics: pass@1, pass@5, pass@10

## Final Results
- pass@1: 1.28%
- pass@5: 6.13%
- pass@10: 11.59%

## File Description
- humaneval_gpt2_full_pass10.jsonl: Model generated code samples
- humaneval_gpt2_full_log.txt: Complete evaluation running log
- eval_humaneval.py: Official HumanEval evaluation script
