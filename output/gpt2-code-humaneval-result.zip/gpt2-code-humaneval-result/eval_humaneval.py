
import argparse
import json
import logging
import os
import sys
from typing import Dict, Any

import torch
from datasets import load_dataset
import evaluate
from transformers import AutoModelForCausalLM, AutoTokenizer

os.environ["HF_ALLOW_CODE_EVAL"] = "1"

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
    stream=sys.stdout,
)
logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Unified HumanEval Evaluation")

    parser.add_argument(
        "--model_path",
        type=str,
        required=True,
        help="Path to the fine-tuned model directory.",
    )
    parser.add_argument(
        "--output_path",
        type=str,
        default="./humaneval_samples.jsonl",
        help="Path to save the intermediate JSONL generation results.",
    )
    parser.add_argument(
        "--gpu_target",
        type=str,
        default="T4",
        choices=["T4", "A100"],
        help="Target hardware architecture.",
    )
    parser.add_argument(
        "--num_samples",
        type=int,
        default=10,
        help="Number of samples to generate per problem.",
    )
    parser.add_argument(
        "--k_values",
        type=int,
        nargs="+",
        default=[1, 5, 10],
        help="List of k values for pass@k metric.",
    )
    return parser.parse_args()


def configure_inference_profile(gpu_target: str) -> Dict[str, Any]:
    profile = {"device": torch.device("cuda" if torch.cuda.is_available() else "cpu")}
    if gpu_target == "A100" and torch.cuda.is_bf16_supported():
        logger.info("Using A100 profile: bfloat16")
        profile["dtype"] = torch.bfloat16
    else:
        logger.info("Using T4 profile: float16")
        profile["dtype"] = torch.float16 if torch.cuda.is_available() else torch.float32
    return profile


def main() -> None:
    args = parse_args()
    hw_profile = configure_inference_profile(args.gpu_target)
    device = hw_profile["device"]

    logger.info("Loading model...")
    tokenizer = AutoTokenizer.from_pretrained(args.model_path)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path, torch_dtype=hw_profile["dtype"]
    ).to(device)
    model.eval()

    logger.info("Loading HumanEval dataset...")
    dataset = load_dataset("openai_humaneval", split="test")

    results = []
    logger.info("Starting code generation...")

    with torch.no_grad():
        for i, task in enumerate(dataset):
            task_id = task["task_id"]
            prompt = task["prompt"]

            inputs = tokenizer(prompt, return_tensors="pt").to(device)

            outputs = model.generate(
                **inputs,
                max_new_tokens=180,
                temperature=0.7,
                do_sample=True,
                top_p=0.95,
                num_return_sequences=args.num_samples,
                pad_token_id=tokenizer.eos_token_id,
            )

            for j in range(args.num_samples):
                gen_tokens = outputs[j][inputs.input_ids.shape[1] :]
                generated_text = tokenizer.decode(gen_tokens, skip_special_tokens=True)

                completion = generated_text.split("\ndef ")[0].split("\nclass ")[0].split("\nif __name__")[0]
                results.append({"task_id": task_id, "completion": completion})

            if (i + 1) % 20 == 0 or (i + 1) == len(dataset):
                logger.info(f"Progress: {i+1}/{len(dataset)}")

    with open(args.output_path, "w") as f:
        for res in results:
            f.write(json.dumps(res) + "\n")

    logger.info("Running pass@k evaluation...")
    code_eval = evaluate.load("code_eval")
    test_cases = [task["test"] for task in dataset]
    predictions = [[] for _ in range(len(dataset))]
    task_id_map = {task["task_id"]: idx for idx, task in enumerate(dataset)}

    for res in results:
        predictions[task_id_map[res["task_id"]]].append(res["completion"])

    pass_at_k, _ = code_eval.compute(
        references=test_cases, predictions=predictions, k=args.k_values, num_workers=8
    )

    print("\n" + "="*60)
    print(f"{'HumanEval Evaluation Result':<30} | {'Value':<25}")
    print("-"*60)
    for k in args.k_values:
        print(f"pass@{k:<28} | {pass_at_k[f'pass@{k}']:<25.2%}")
    print("="*60)


if __name__ == "__main__":
    main()
